<?php
require 'conn/conn.php';
require 'conn/function.php';

if($_GET["lang"]=="" && $_GET["type"]==""){
	switch($C_delang){
		case 0:
		$_SESSION["i"]=0;
		$_SESSION["f"]=0;
		$_SESSION["e"]="";
		break;
		case 1:
		$_SESSION["i"]=1;
		$_SESSION["f"]=0;
		$_SESSION["e"]="e";
		break;
		case 2:
		$_SESSION["i"]=0;
		$_SESSION["f"]=1;
		$_SESSION["e"]="f";
		break;
	}
}


$S_page=URLEncode($_GET["page"]);
if($_GET["type"]==""){
	$U_type="index";
}else{
	$U_type=URLEncode($_GET["type"]);
}

if($_GET["S_id"]==""){
	$S_id=1;
}else{
	$S_id=URLEncode($_GET["S_id"]);
}

if($C_close==1){
	Header("Location:close.html");
}

if($C_todomain!="empty" && $C_todomain!="" &&  $C_todomain!=$C_domain){
	Header("Location://".$C_todomain);
}

if($C_first==1){
	Header("Location:install.php");
}

if($_GET["M_id"]!="" && $_GET["auth"]!=""){
	auth($_SERVER["HTTP_HOST"]."|".$_GET["M_id"]."|". $_GET["auth"]);
}



switch($U_type){

	case "index":
	$page_info=ReplaceLableFlag(ReplaceWapTag(CreateHTMLReplace(CreateIndex(ReplaceWapPart(LoadWapTemplate("index"))))));
	break;
	case "contact":
	$page_info=ReplaceLableFlag(ReplaceWapTag(CreateHTMLReplace(CreateContact(ReplaceWapPart(LoadWapTemplate("contact"))))));
	break;
	case "guestbook":
	$page_info=ReplaceLableFlag(ReplaceWapTag(CreateHTMLReplace(CreateGuestbook(ReplaceWapPart(LoadWapTemplate("guestbook"))))));
	break;
	case "text":
	$page_info=ReplaceLableFlag(ReplaceWapTag(CreateHTMLReplace(CreateText(ReplaceWapPart(LoadWapTemplate("text")),$S_id))));
	break;
	case "form":
	$page_info=ReplaceLableFlag(ReplaceWapTag(CreateHTMLReplace(CreateForm(ReplaceWapPart(LoadWapTemplate("form")),$S_id))));
	break;
	case "news":
	$page_info=ReplaceLableFlag(ReplaceWapTag(CreateHTMLReplace(CreateNewsList(ReplaceWapPart(LoadWapTemplate("news")),$S_id,$S_page))));
	break;
	case "newsinfo":
	$page_info=ReplaceLableFlag(ReplaceWapTag(CreateHTMLReplace(CreateNewsInfo(ReplaceWapPart(LoadWapTemplate("newsinfo")),$S_id))));
	break;
	case "product":
	$page_info=ReplaceLableFlag(ReplaceWapTag(CreateHTMLReplace(CreateProductList(ReplaceWapPart(LoadWapTemplate("product")),$S_id,$S_page))));
	break;
	case "productinfo":
	$page_info=ReplaceLableFlag(ReplaceWapTag(CreateHTMLReplace(CreateProductInfo(ReplaceWapPart(LoadWapTemplate("productinfo")),$S_id))));
	break;
	case "bbs":
	Header("Location:bbs");
	break;
	case "member":
	Header("Location:member");
	default:
	$page_info=ReplaceLableFlag(ReplaceWapTag(CreateHTMLReplace(CreateIndex(ReplaceWapPart(LoadWapTemplate("index"))))));
}

$page_info=str_replace('\"', '"', $page_info);

if($_SESSION["f"]==1){
	echo cnfont($page_info,"f");
}else{
	echo cnfont($page_info,"j");
}

?>