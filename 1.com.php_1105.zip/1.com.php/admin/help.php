﻿<?php 
require '../conn/conn2.php';
require '../conn/function.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
<link rel="shortcut icon" href="<?php echo $C_dir.$C_ico?>" type="image/x-icon" />
<link rel="Bookmark" href="<?php echo $C_dir.$C_ico?>" />
<title>用户使用手册</title>
<link href="css/jquery-accordion-menu.css" rel="stylesheet" type="text/css" />
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" />
<style type="text/css">
body{margin:0px; overflow:hidden }
</style>
<script language="JavaScript">
function show()
{
document.getElementById("iframeid").style.height=(document.documentElement.clientHeight)+"px";
}
window.onresize = function(){
document.getElementById("iframeid").style.height=(document.documentElement.clientHeight)+"px";
}
</script>
</head>
<body>
<iframe src="http://www.s-cms.cn/help?page=<?php echo $_GET["page"]?>" width="100%" frameBorder="0" id="iframeid" onLoad="show()"></iframe>
</body>
</html>