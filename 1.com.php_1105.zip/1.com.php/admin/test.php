<?php
$update=file_get_contents("http://shanlingtest.oss-cn-shenzhen.aliyuncs.com/php/update.txt");
$update=str_replace(PHP_EOL,"",$update);
$update=trim($update,"\xEF\xBB\xBF");
echo $update;
?>