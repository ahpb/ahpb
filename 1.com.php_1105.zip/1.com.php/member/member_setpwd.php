<?php 
require '../conn/conn2.php';
require '../conn/function.php';

$action=$_GET["action"];
$M_pwdcode=urlencode($_GET["M_pwdcode"]);
$genkey=gen_key(20);
$from=$_SESSION["from"];
if($from==""){
$from="../member/index.asp";
}
$sql="Select * from SL_member Where M_pwdcode='".$M_pwdcode."'";
 
    $result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
    $M_login=$row["M_login"];
    }else{
    box("重置码错误!","member_login.asp","error");
    }
if($action=="setpwd"){
if($_POST["M_newpwd"]==$_POST["M_newpwd2"] && $_POST["M_newpwd"]!=""){
mysqli_query($conn,"update SL_member set M_pwd='".md5($_POST["M_newpwd"])."' where M_pwdcode='".$M_pwdcode."'");
mysqli_query($conn,"update SL_member set M_pwdcode='' where M_pwdcode='".$M_pwdcode."'");
box("重置密码成功，请返回登录!","member_login.asp","success");
}else{
box("两次密码不一致!","back","error");
}
}

?>

<!DOCTYPE HTML>
<html>
<head>
<title>设置密码</title>
<meta charset="utf-8" />
<meta content="width=device-width, initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
<meta content="yes" name="apple-mobile-web-app-capable" />
<meta content="black" name="apple-mobile-web-app-status-bar-style" />
<meta content="telephone=yes" name="format-detection" />
<meta content="email=no" name="format-detection" />
<meta name="keywords" content=""  />
<meta name="description" content="" />
<link rel="stylesheet" href="../css/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.css">
<script src="js/jquery.min.js" type="text/javascript" ></script>
<script src="js/bootstrap.min.js"></script>
<style>
body{ background: #eeeeee; padding-top:0px;}
a{ text-decoration:none} 
a:hover{ text-decoration:none;} 
</style>
<script type="text/javascript">
function test(){
$.post("post.asp",
    {
      genkey:"<%=genkey%>",
    },
    function(data){
	if(data==1){
	document.location.href='<%=URLDecode(from)%>'
	}
    });
}
setInterval("test()",3000); //每3秒钟执行一次test()
</SCRIPT>
</head>
<body>
<div style=" max-width: 600px; width: 100%; margin: 0px auto; padding: 20px;">
<div style="text-align: center; padding: 20px;"><img src="../<%=C_logo%>" width="200"></div>
<div class="panel  panel-info ng-scope">
        <div class="panel-heading">
         设置密码
        </div>
        <div class="panel-body">
<form class="form-horizontal" method="post" action="?action=setpwd&M_pwdcode=<%=M_pwdcode%>">
<div class="form-group">
          <label class="col-sm-2 control-label">用户名</label>
          <div class="col-sm-10">
          <%=M_login%>
          </div>
          </div>
<div class="form-group">
          <label class="col-sm-2 control-label">设置密码</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="M_newpwd" placeholder="设置密码">
          </div>
          </div>
          <div class="form-group">
          <label class="col-sm-2 control-label">确认密码</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="M_newpwd2" placeholder="确认密码">
          </div>
          </div>
          <div class="form-group">
          <label class="col-sm-2 control-label"></label>
          <div class="col-sm-10">
            <button type="submit" class="btn btn-info btn-block">设置密码</button>
          </div>
          </div>
          <div class="form-group">
          <label class="col-sm-2 "></label>
          <div class="col-sm-10 ">
          <img src='http://static.websiteonline.cn/website/qr/index.php?url=http://<%=C_domain%><%=C_dir%>wxpay/login.asp?genkey=<%=genkey%>' style="display: none;">
            <%if C_qqkj=1 then%>
            <a href="../qq/qqlogin.asp"><span class="label" style="background: #0099ff;"><i class="fa fa-qq"></i> QQ登录</span></a>
            <%end if%>
            <%if C_wxkj=1 then%>
            <a href="<%if wapstr then%>http://<%=C_domain%><%=C_dir%>wxpay/login.asp?genkey=<%=genkey%><%else%>javascript:;<%end if%>" <%if wapstr=false then%>data-toggle="tooltip" <%end if%>title="<div style='text-align:center;padding:10px;'><img src='http://static.websiteonline.cn/website/qr/index.php?url=http://<%=C_domain%><%=C_dir%>wxpay/login.asp?genkey=<%=genkey%>' width='150'></div>"><span class="label" style="background: #009900;"><i class="fa fa-wechat"></i> 微信登录</span></a>
            <%end if%>
            <div class="pull-right">
            <a href="../"><span class="label" style="background: #BBBBBB;">返回首页</span></a>
            <a href="member_reg.asp"><span class="label" style="background: #BBBBBB;">注册</span></a>
            <a href="member_login.asp"><span class="label" style="background: #BBBBBB;">登录</span></a>
            </div>
          </div>
          </div>
</form>
</div>
</div>
</div>
<script>
	$(function () { $("[data-toggle='tooltip']").tooltip({html : true }); });
</script>
</body>
</html>