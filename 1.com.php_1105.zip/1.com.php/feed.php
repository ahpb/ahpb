﻿<?php
require 'conn/conn.php';
require 'conn/function.php';
?><?xml version="1.0" encoding="UTF-8"?><rss version="2.0"
	xmlns:content="http://purl.org/rss/1.0/modules/content/"
	xmlns:wfw="http://wellformedweb.org/CommentAPI/"
	xmlns:dc="http://purl.org/dc/elements/1.1/"
	xmlns:atom="http://www.w3.org/2005/Atom"
	xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
	xmlns:slash="http://purl.org/rss/1.0/modules/slash/"
	>

<channel>
	<title><?php echo lang($C_webtitle)?></title>
	<atom:link href="http://<?php echo $C_domain?><?php echo $C_dir?>feed.asp" rel="self" type="application/rss+xml" />
	<link>http://<?php echo $C_domain?></link>
	<description><?php echo lang($C_description)?></description>
	<lastBuildDate>Thu, 24 Aug 2017 09:53:01 +0000</lastBuildDate>
	<language>zh-CN</language>
	<sy:updatePeriod>hourly</sy:updatePeriod>
	<sy:updateFrequency>1</sy:updateFrequency>
	<generator>https://www.s-cms.cn/?v=4.7.5</generator>
<?php
Set rs= Server.CreateObject("ADODB.RecordSet")
sql="select * from SL_text order by T_id desc"
rs.open sql,conn,1,1
if not rs.eof then
Do while Not rs.eof
?>
	<item>
		<title><?php echo lang(rs("T_title"))?></title>
		<link><![CDATA[<?php if C_html=0 then
response.write "http://"&C_domain&C_dir&"?type=text&S_id="&rs("T_id")
		else
response.write "http://"&C_domain&C_dir&"html/about/"&rs("T_id")&".html"
	end if
		?>]]></link>
		<pubDate><?php echo DateToRFC822(now())?></pubDate>
		<dc:creator><![CDATA[<?php echo lang(C_webtitle)?>]]></dc:creator>
		<category><![CDATA[<?php echo lang(rs("T_title"))?>]]></category>
		<description><![CDATA[<?php echo lang(rs("T_description"))?>]]></description>
		<content:encoded><![CDATA[<?php echo lang(replace(rs("T_content"),"{@SL_安装目录}",C_dir))?>]]></content:encoded>
		</item>
<?php
rs.movenext
		loop
	end if
rs.close
set rs=nothing

Set rs= Server.CreateObject("ADODB.RecordSet")
sql="select * from SL_news,SL_nsort where N_sort=S_id order by N_id desc"
rs.open sql,conn,1,1
if not rs.eof then
Do while Not rs.eof
?>
	<item>
		<title><?php echo lang(rs("N_title"))?></title>
		<link><![CDATA[<?php if C_html=0 then
response.write "http://"&C_domain&C_dir&"?type=news&S_id="&rs("N_id")
		else
response.write "http://"&C_domain&C_dir&"html/news/"&rs("N_id")&".html"
	end if
		?>]]></link>
		<pubDate><?php echo DateToRFC822(now())?></pubDate>
		<dc:creator><![CDATA[<?php echo rs("N_author")?>]]></dc:creator>
		<category><![CDATA[<?php echo lang(rs("S_title"))?>]]></category>
		<description><![CDATA[<?php echo lang(rs("N_description"))?>]]></description>
		<content:encoded><![CDATA[<?php echo lang(replace(rs("N_content"),"{@SL_安装目录}",C_dir))?>]]></content:encoded>
		</item>
<?php
rs.movenext
		loop
	end if
rs.close
set rs=nothing

Set rs= Server.CreateObject("ADODB.RecordSet")
sql="select * from SL_product,SL_psort where P_sort=S_id order by P_id desc"
rs.open sql,conn,1,1
if not rs.eof then
Do while Not rs.eof
?>
	<item>
		<title><?php echo lang(rs("P_title"))?></title>
		<link><![CDATA[<?php if C_html=0 then
response.write "http://"&C_domain&C_dir&"?type=product&S_id="&rs("P_id")
		else
response.write "http://"&C_domain&C_dir&"html/product/"&rs("P_id")&".html"
	end if
		?>]]></link>
		<pubDate><?php echo DateToRFC822(now())?></pubDate>
		<dc:creator><![CDATA[<?php echo lang(C_webtitle)?>]]></dc:creator>
		<category><![CDATA[<?php echo lang(rs("S_title"))?>]]></category>
		<description><![CDATA[<?php echo lang(rs("P_description"))?>]]></description>
		<content:encoded><![CDATA[<?php echo lang(replace(rs("P_content"),"{@SL_安装目录}",C_dir))?>]]></content:encoded>
		</item>
<?php
rs.movenext
		loop
	end if
rs.close
set rs=nothing
?>
	</channel>
</rss>
<?php
Function DateToRFC822(byVal dtaVal)
    Dim strCurLocale : strCurLocale = GetLocale()
    SetLocale("en-gb")
    dtaVal = CDate(dtaVal)
    DateToRFC822 = WeekdayName(Weekday(dtaVal),True)&","&_
                   Right("0"&Day(dtaVal),2)&" "&_
                   MonthName(Month(dtaVal),True)&" "&_
                   Year(dtaVal)&" "&_
                   Right("0"&Hour(dtaVal),2)&":"&_
                   Right("0"&Minute(dtaVal),2)&":"& _
                   Right("0"&Second(dtaVal),2)&" "& _
                   " +0800"
    SetLocale(strCurLocale)
End Function 
?>